var dir_b13500dca17cbd5223bbca1b6145d249 =
[
    [ "SoftwareArchitecture", "dir_f1d5f485efc958956c64888c5cd2fd8b.html", "dir_f1d5f485efc958956c64888c5cd2fd8b" ]
];