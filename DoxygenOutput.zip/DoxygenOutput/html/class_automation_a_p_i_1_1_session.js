var class_automation_a_p_i_1_1_session =
[
    [ "MakePart", "class_automation_a_p_i_1_1_session.html#a9bc4f856449824a3a367b4efdab07838", null ],
    [ "OpenPart", "class_automation_a_p_i_1_1_session.html#abeee0dbb1146923bd354f6988a03e3ba", null ]
];