var class_automation_a_p_i_1_1_block_builder =
[
    [ "BlockBuilderTypes", "class_automation_a_p_i_1_1_block_builder.html#a9095bc936c5de1706283d36dcd0ed9cb", [
      [ "TypesTwoPointsAndHeight", "class_automation_a_p_i_1_1_block_builder.html#a9095bc936c5de1706283d36dcd0ed9cba984894108fda4d41eb325f6454eb6c24", null ],
      [ "TypesDiagonalPoints", "class_automation_a_p_i_1_1_block_builder.html#a9095bc936c5de1706283d36dcd0ed9cbadc7f70cb42dd95c2531f1bc22f290353", null ]
    ] ],
    [ "Commit", "class_automation_a_p_i_1_1_block_builder.html#aa26db68ed79e3d57d1b00e1383ad5e9e", null ]
];