var class_automation_a_p_i_1_1_part =
[
    [ "Features", "class_automation_a_p_i_1_1_part.html#a9f8f1e227e4b1387dae8f93effb06800", null ],
    [ "MakeWidgetFeature", "class_automation_a_p_i_1_1_part.html#ae2ab1e4d7a2054cc6b2d0dfc1f3f5773", null ],
    [ "Routing", "class_automation_a_p_i_1_1_part.html#a66c619d9137731f9b2fc585a08803f0c", null ],
    [ "Save", "class_automation_a_p_i_1_1_part.html#a3c3ecd459c51189b79639eae97923216", null ]
];