var searchData=
[
  ['getsession_0',['GetSession',['../class_automation_a_p_i_1_1_session.html#a42194859a423516571219c887ebc1d95',1,'AutomationAPI::Session']]]
];
