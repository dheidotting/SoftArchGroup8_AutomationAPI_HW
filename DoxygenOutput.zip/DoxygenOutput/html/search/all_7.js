var searchData=
[
  ['openpart_0',['OpenPart',['../class_automation_a_p_i_1_1_session.html#abeee0dbb1146923bd354f6988a03e3ba',1,'AutomationAPI::Session']]]
];
