var hierarchy =
[
    [ "AutomationAPI::BlockBuilderImpl", "class_automation_a_p_i_1_1_block_builder_impl.html", null ],
    [ "AutomationAPI::FeatureCollection", "class_automation_a_p_i_1_1_feature_collection.html", null ],
    [ "AutomationAPI::IBuilder", "class_automation_a_p_i_1_1_i_builder.html", [
      [ "AutomationAPI::BlockBuilder", "class_automation_a_p_i_1_1_block_builder.html", null ],
      [ "AutomationAPI::ScrewBuilder", "class_automation_a_p_i_1_1_screw_builder.html", null ],
      [ "AutomationAPI::WireBuilder", "class_automation_a_p_i_1_1_wire_builder.html", null ]
    ] ],
    [ "AutomationAPI::ICADObject", "class_automation_a_p_i_1_1_i_c_a_d_object.html", [
      [ "AutomationAPI::CADObject", "class_automation_a_p_i_1_1_c_a_d_object.html", [
        [ "AutomationAPI::Block", "class_automation_a_p_i_1_1_block.html", null ],
        [ "AutomationAPI::Extrude", "class_automation_a_p_i_1_1_extrude.html", null ],
        [ "AutomationAPI::Wire", "class_automation_a_p_i_1_1_wire.html", null ]
      ] ]
    ] ],
    [ "AutomationAPI::Part", "class_automation_a_p_i_1_1_part.html", null ],
    [ "AutomationAPI::PartImpl", "class_automation_a_p_i_1_1_part_impl.html", null ],
    [ "AutomationAPI::RoutingCollection", "class_automation_a_p_i_1_1_routing_collection.html", null ],
    [ "AutomationAPI::ScrewBuilderImpl", "class_automation_a_p_i_1_1_screw_builder_impl.html", null ],
    [ "AutomationAPI::ScrewManager", "class_automation_a_p_i_1_1_screw_manager.html", null ],
    [ "AutomationAPI::Session", "class_automation_a_p_i_1_1_session.html", null ]
];