var annotated_dup =
[
    [ "AutomationAPI", null, [
      [ "Block", "class_automation_a_p_i_1_1_block.html", null ],
      [ "BlockBuilder", "class_automation_a_p_i_1_1_block_builder.html", "class_automation_a_p_i_1_1_block_builder" ],
      [ "BlockBuilderImpl", "class_automation_a_p_i_1_1_block_builder_impl.html", null ],
      [ "CADObject", "class_automation_a_p_i_1_1_c_a_d_object.html", null ],
      [ "Extrude", "class_automation_a_p_i_1_1_extrude.html", null ],
      [ "FeatureCollection", "class_automation_a_p_i_1_1_feature_collection.html", "class_automation_a_p_i_1_1_feature_collection" ],
      [ "IBuilder", "class_automation_a_p_i_1_1_i_builder.html", null ],
      [ "ICADObject", "class_automation_a_p_i_1_1_i_c_a_d_object.html", null ],
      [ "Part", "class_automation_a_p_i_1_1_part.html", "class_automation_a_p_i_1_1_part" ],
      [ "PartImpl", "class_automation_a_p_i_1_1_part_impl.html", null ],
      [ "RoutingCollection", "class_automation_a_p_i_1_1_routing_collection.html", null ],
      [ "ScrewBuilder", "class_automation_a_p_i_1_1_screw_builder.html", "class_automation_a_p_i_1_1_screw_builder" ],
      [ "ScrewBuilderImpl", "class_automation_a_p_i_1_1_screw_builder_impl.html", null ],
      [ "ScrewManager", "class_automation_a_p_i_1_1_screw_manager.html", "class_automation_a_p_i_1_1_screw_manager" ],
      [ "Session", "class_automation_a_p_i_1_1_session.html", "class_automation_a_p_i_1_1_session" ],
      [ "Wire", "class_automation_a_p_i_1_1_wire.html", null ],
      [ "WireBuilder", "class_automation_a_p_i_1_1_wire_builder.html", "class_automation_a_p_i_1_1_wire_builder" ]
    ] ]
];