var dir_5d0de39ff718a1db17858ba64f0341ca =
[
    [ "AutomationAPI_Block.h", "_automation_a_p_i___block_8h_source.html", null ],
    [ "AutomationAPI_BlockBuilder.h", "_automation_a_p_i___block_builder_8h_source.html", null ],
    [ "AutomationAPI_CADObject.h", "_automation_a_p_i___c_a_d_object_8h_source.html", null ],
    [ "AutomationAPI_Extrude.h", "_automation_a_p_i___extrude_8h_source.html", null ],
    [ "AutomationAPI_FeatureCollection.h", "_automation_a_p_i___feature_collection_8h_source.html", null ],
    [ "AutomationAPI_IBuilder.h", "_automation_a_p_i___i_builder_8h_source.html", null ],
    [ "AutomationAPI_ICADObject.h", "_automation_a_p_i___i_c_a_d_object_8h_source.html", null ],
    [ "AutomationAPI_Part.h", "_automation_a_p_i___part_8h_source.html", null ],
    [ "AutomationAPI_RoutingCollection.h", "_automation_a_p_i___routing_collection_8h_source.html", null ],
    [ "AutomationAPI_ScrewBuilder.h", "_automation_a_p_i___screw_builder_8h_source.html", null ],
    [ "AutomationAPI_ScrewManager.h", "_automation_a_p_i___screw_manager_8h_source.html", null ],
    [ "AutomationAPI_Session.h", "_automation_a_p_i___session_8h_source.html", null ],
    [ "AutomationAPI_Wire.h", "_automation_a_p_i___wire_8h_source.html", null ],
    [ "AutomationAPI_WireBuilder.h", "_automation_a_p_i___wire_builder_8h_source.html", null ],
    [ "AutomationBindingExports.h", "_automation_binding_exports_8h_source.html", null ],
    [ "framework.h", "framework_8h_source.html", null ]
];