var class_automation_a_p_i_1_1_screw_manager =
[
    [ "CreateScrewBuilder", "class_automation_a_p_i_1_1_screw_manager.html#a702befc3a2966baf04a558d4b7097202", null ]
];